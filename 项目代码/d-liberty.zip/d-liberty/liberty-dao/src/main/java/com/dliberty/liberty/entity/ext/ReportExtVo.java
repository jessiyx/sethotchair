package com.dliberty.liberty.entity.ext;

public class ReportExtVo {

	private String name;
	
	private Integer data;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getData() {
		return data;
	}

	public void setData(Integer data) {
		this.data = data;
	}

	
	
}
