package com.dliberty.liberty;

public class Test {

	public static void main(String[] args) {
		/*List<String> numbers = Arrays.asList("3", "2", "2", "3", "7", "3", "5");

		long count = numbers.parallelStream().filter(string -> !numbers.isEmpty()).count();
		
		System.out.println(count);
		
		long count2 = numbers.stream().filter(string -> !numbers.isEmpty()).count();
		
		System.out.println(count2);
		
		Map<String,String> map = new HashMap<>();
		
		map.put("123", "123");*/
		
		
		int b = -10;
		System.out.println(b >> 1);
		
		
		
	}
}
