package com.dliberty.liberty.weixin.service;


/**
 * 微信api的基础支持
 * @author gjt
 *
 */
public interface WeixinBaseSupportService {


	/**
	 * 获取access_token
	 * @return
	 */
	public String accessToken();
	
	
	
}
