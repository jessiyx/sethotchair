package com.dliberty.liberty.lang.data;

/**
*
*
* @author GuoJingtao
* @author <a href="mailto:gjt0206@163.com">guojingtao</a>
*/
public class StringUtils extends org.apache.commons.lang3.StringUtils {
}
